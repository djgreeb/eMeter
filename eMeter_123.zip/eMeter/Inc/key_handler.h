/////////////////////////////////////////////////////////////////////////////////////////////////
// 	Key Handler
//	product: eMeter
//
//
//
//
//	Author: Anatska Andrei
//
/////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdint.h"
#include "ssd1306_32.h"

///////////////////////////////////////////////////////////////////	
//	
//	KEY HANDLER
//	
void key_handler(void)
	{
	if(HAL_GPIO_ReadPin(BUTTON_GPIO_Port, BUTTON_Pin)==0)			//////////////////////////////////////////////////button handler
		{
		if(BUTTON_PRESSED==0)
			{
			TURN_OFF_TIM = HAL_GetTick();
			last_active = TURN_OFF_TIM;	
			BUTTON_PRESSED = 1;	
			}			
		else
			{
			if((HAL_GetTick() - TURN_OFF_TIM)>1500)
				{
				POWER_OFF();	
				}
			}						
		}		
	else if(HAL_GPIO_ReadPin(BUTTON_GPIO_Port, BUTTON_Pin)==1 && BUTTON_PRESSED==1)
		{
		need_update_display = 0;			//block previous measurement update	
			
		if(enter_settings==0)	
			{
			if(CHARGE_MODE==0)	
				{
				if(METER_MODE<5)
					{
					METER_MODE++;	
					}
				else
					{
					METER_MODE = 0;	
					}
			
				if((display_invert==1) && (METER_MODE!=PROBE))							//canceling invert mode
					{
					ssd1306_I2C_Write(SSD1306_I2C_ADDR, 0x00, 0xA6);
					display_invert = 0;	
					}		
				
				if(METER_MODE==VOLT)
					{
					ADC_SPEED(DEF_TIME_FREQ);	
					HAL_GPIO_WritePin(GPIOA, OHM_EN_Pin, GPIO_PIN_RESET);	
					HAL_GPIO_WritePin(GPIOA, CHRG_EN_Pin, GPIO_PIN_RESET);			
					SSD1306_DrawFilledRectangle(0, 0, 128, 32, SSD1306_COLOR_BLACK);			//	
					Draw_Battery();																												//
					previous_battery_level = 0;																						// force redraw
					Draw_Level_Battery(BAT_PIX_LVL);																								//
					sprintf((char*)Buf, "VOLTAGE DC");	
					SSD1306_GotoXY(0, 0);
					SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);		
					SSD1306_UpdateScreen();
					Draw_Animation_MENU(METER_MODE);
					SWITCH_MODE(MODE_PM3);		
					HAL_Delay(650);	
					SSD1306_DrawFilledRectangle(0, 8, 128, 24, SSD1306_COLOR_BLACK);	
					need_update_display = 1;	
					}
				else if(METER_MODE==OHM)
					{
					ADC_SPEED(DEF_TIME_FREQ);	
					HAL_GPIO_WritePin(GPIOA, CHRG_EN_Pin, GPIO_PIN_RESET);		
					HAL_GPIO_WritePin(GPIOA, OHM_EN_Pin, GPIO_PIN_SET);		
					SSD1306_DrawFilledRectangle(0, 0, 128, 32, SSD1306_COLOR_BLACK);			//	
					Draw_Battery();																												//
					previous_battery_level = 0;																						// force redraw	
					Draw_Level_Battery(BAT_PIX_LVL);																								//
					sprintf((char*)Buf, "RESISTANCE");	
					SSD1306_GotoXY(0, 0);
					SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);		
					SSD1306_UpdateScreen();
					Draw_Animation_MENU(METER_MODE);	
					SWITCH_MODE(MODE_R100);	
					HAL_Delay(650);	
					SSD1306_DrawFilledRectangle(0, 8, 128, 24, SSD1306_COLOR_BLACK);			
					}
				else if(METER_MODE==PROBE)
					{
					ADC_SPEED(DEF_TIME_FREQ);	
					HAL_GPIO_WritePin(GPIOA, CHRG_EN_Pin, GPIO_PIN_RESET);	
					HAL_GPIO_WritePin(GPIOA, OHM_EN_Pin, GPIO_PIN_SET);	
					SWITCH_MODE(MODE_PRB);		
					SSD1306_DrawFilledRectangle(0, 0, 128, 32, SSD1306_COLOR_BLACK);			//	
					Draw_Battery();																												//
					previous_battery_level = 0;																						// force redraw	
					Draw_Level_Battery(BAT_PIX_LVL);																								//
					sprintf((char*)Buf, "PROBE");	
					SSD1306_GotoXY(0, 0);
					SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);		
					SSD1306_UpdateScreen();	
					Draw_Animation_MENU(METER_MODE);	
					HAL_Delay(650);		
					SSD1306_DrawFilledRectangle(0, 8, 128, 24, SSD1306_COLOR_BLACK);		
					}
				else if(METER_MODE==CAP)
					{
					ADC_SPEED(F5KS);		
					HAL_GPIO_WritePin(GPIOA, CHRG_EN_Pin, GPIO_PIN_RESET);	
					HAL_GPIO_WritePin(GPIOA, OHM_EN_Pin, GPIO_PIN_SET);	
					SWITCH_MODE(MODE_CP);	
					NULLCAP = 4035;	
					cap_range = 0;	
					SSD1306_DrawFilledRectangle(0, 0, 128, 32, SSD1306_COLOR_BLACK);			//	
					Draw_Battery();																												//
					previous_battery_level = 0;																						// force redraw	
					Draw_Level_Battery(BAT_PIX_LVL);																								//
					sprintf((char*)Buf, "CAPACITY");	
					SSD1306_GotoXY(0, 0);
					SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);		
					SSD1306_UpdateScreen();		
					Draw_Animation_MENU(METER_MODE);	
					HAL_Delay(650);		
					SSD1306_DrawFilledRectangle(0, 8, 128, 24, SSD1306_COLOR_BLACK);			
					}	
				else if(METER_MODE==OSC)
					{
					if(STNGSBASE[2]<10)
						{
						ADC_SPEED(STNGSBASE[2]);	
						}
					else
						{
						ADC_SPEED(F200KS);		//AUTO MODE	
						}
					HAL_GPIO_WritePin(GPIOA, OHM_EN_Pin, GPIO_PIN_RESET);	
					HAL_GPIO_WritePin(GPIOA, CHRG_EN_Pin, GPIO_PIN_RESET);
					SWITCH_MODE(OSC_P6);
					SSD1306_DrawFilledRectangle(0, 0, 128, 32, SSD1306_COLOR_BLACK);			//	
					Draw_Battery();																												//
					previous_battery_level = 0;																						// force redraw	
					Draw_Level_Battery(BAT_PIX_LVL);																								//
					sprintf((char*)Buf, "OSCILLOSCOPE");	
					SSD1306_GotoXY(0, 0);
					SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);		
					SSD1306_UpdateScreen();	
					Draw_Animation_MENU(METER_MODE);	
					HAL_Delay(650);	
					SSD1306_DrawFilledRectangle(0, 0, 128, 32, SSD1306_COLOR_BLACK);
					sprintf((char*)Buf, "+2.00V");	
					SSD1306_GotoXY(0, 0);
					SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);	
					sprintf((char*)Buf, "-2.00V");	
					SSD1306_GotoXY(0, 25);
					SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);		
					Draw_osc_background();
					need_update_display = 1;	
					}		
				else if(METER_MODE==STNGS)
					{
					ADC_SPEED(DEF_TIME_FREQ);	
					SWITCH_MODE(MODE_STN);	
					HAL_GPIO_WritePin(GPIOA, OHM_EN_Pin, GPIO_PIN_RESET);	
					HAL_GPIO_WritePin(GPIOA, CHRG_EN_Pin, GPIO_PIN_RESET);	
					SSD1306_DrawFilledRectangle(0, 0, 128, 32, SSD1306_COLOR_BLACK);			//	
					Draw_Battery();																												//
					previous_battery_level = 0;																						// force redraw	
					Draw_Level_Battery(BAT_PIX_LVL);																			//
					sprintf((char*)Buf, "SETTINGS");	
					SSD1306_GotoXY(0, 0);
					SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);		
					SSD1306_UpdateScreen();
					Draw_Animation_MENU(METER_MODE);	
					HAL_Delay(650);					
					SSD1306_DrawFilledRectangle(0, 8, 128, 24, SSD1306_COLOR_BLACK);
					sprintf((char*)Buf, "Short the needle");	
					SSD1306_GotoXY(22, 15);
					SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);
					sprintf((char*)Buf, "to enter the settings");	
					SSD1306_GotoXY(7, 25);
					SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);
					enter_settings = 0;
					}
				}
			}
		else		//enter settings
			{
			if(edit_parameter==0)	
				{
				if(sett_CurrentCursorPosition<3)
					{
					sett_CurrentCursorPosition++;	
					}
				else if((sett_current_element_pos+sett_CurrentCursorPosition)<TOTAL_ELEMENTS)
					{
					sett_current_element_pos++;	
					}
				else
					{
					sett_current_element_pos = 1;	
					sett_CurrentCursorPosition = 0;	
					}
				SSD1306_Fill(SSD1306_COLOR_BLACK);	
				ReDrawScroll(TOTAL_ELEMENTS, sett_current_element_pos);	
				int_SETT_DRAW_ALL_SETTINGS();	
				need_update_display = 1;	
				}
			else					//edit parameters
				{
				if((sett_current_element_pos+sett_CurrentCursorPosition)>1 && (sett_current_element_pos+sett_CurrentCursorPosition)<6)	
					{	
					if(sett_current_element_pos+sett_CurrentCursorPosition==2)	//Brightness
						{
						if(STNGSBASE[0]<15)
							{
							STNGSBASE[0]++;	
							}	
						else
							{
							STNGSBASE[0] = 0;	
							}						
						ssd1306_I2C_Write(0x78, 0x00, (0x81));								//Set Contrast Control
						ssd1306_I2C_Write(0x78, 0x00, (16*STNGSBASE[0]));			//
						}
					else if(sett_current_element_pos+sett_CurrentCursorPosition==3)	//Auto off
						{
						if(STNGSBASE[1]<10)
							{
							STNGSBASE[1]++;	
							}	
						else
							{
							STNGSBASE[1] = 0;	
							}	
						}
					else if(sett_current_element_pos+sett_CurrentCursorPosition==4)	//Osc. Scan
						{
						if(STNGSBASE[2]<10)
							{
							STNGSBASE[2]++;	
							}	
						else
							{
							STNGSBASE[2] = 0;	
							}
						}						
					else if(sett_current_element_pos+sett_CurrentCursorPosition==5)	//Osc. Sync
						{
						if(STNGSBASE[3]==0)
							{
							STNGSBASE[3] = 1;	
							}
						else
							{
							STNGSBASE[3] = 0;		
							}
						}	
					SSD1306_Fill(SSD1306_COLOR_BLACK);	
					ReDrawScroll(TOTAL_ELEMENTS, sett_current_element_pos);	
					int_SETT_DRAW_ALL_SETTINGS();	
					need_update_display = 1;		
					}			
				}				
			}			
		BUTTON_PRESSED = 0;	
		}	
	}	


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



