/////////////////////////////////////////////////////////////////////////////////////////////////
// 	Global variables
//	product: eMeter
//
//
//
//
//	Author: Anatska Andrei
//
/////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdint.h"

uint8_t TIM_DIV = 0;
uint32_t ADC_TEMP = 0;
uint16_t PREVIOUS_VOLTAGE = 0;
uint8_t need_update_display = 0;
uint8_t display_invert = 0;
char Buf[20]={0};						//buffer for display symbols


///////////////////////////////////////BATTERY
uint16_t main_cycle = 0;
uint32_t timestamp = 0;
uint32_t temptick = 0;
uint32_t last_active = 0;
uint32_t tmout_active = 0xFFFFFFFF;
uint8_t CHARGE_MODE = 0;
uint8_t CURRENT_ON = 0;

	


uint8_t previous_battery_level = 0;
uint8_t CURRENT_ADC_CH = 0;
uint8_t BAT_PIX_LVL = 0;				//0...12
uint32_t BAT_V_LVL = 0;				//0.00...4.20V
uint32_t BAT_INDICATE = 0;				//0.00...4.20V
uint32_t INPUT_V_LVL = 0;				//00.00...13.00V
uint16_t cnt;

uint16_t previous_BAT_INDICATE = 0xFFFF;		
uint16_t previous_INPUT_V_LVL = 0xFFFF;	

#define ADC_NEEDLE	0
#define ADC_BATT		1

uint8_t image_charge[36] = {
    0x07, 0xfc, 
    0x0f, 0xf8, 
    0x0f, 0xf0, 
    0x1f, 0xe0, 
    0x1f, 0xc0, 
    0x3f, 0x80, 
    0x3f, 0x00, 
    0x7e, 0x00, 
    0x7f, 0xe0, 
    0x0f, 0xc0, 
    0x1f, 0x80, 
    0x1f, 0x00, 
    0x3e, 0x00, 
    0x3c, 0x00, 
    0x78, 0x00, 
    0x70, 0x00, 
    0xe0, 0x00, 
    0xc0, 0x00};

///////////////////////////////////////TIMER
uint16_t delay_factor = 7;
uint8_t CURRENT_FxMS = 0;


#define DEF_TIME_FREQ 10
#define F1MS			9
#define F500KS		8
#define F200KS		7
#define F100KS		6
#define F50KS			5
#define F20KS			4
#define F10KS			3
#define F5KS			2
#define F2KS			1
#define F1KS			0


///////////////////////////////////////VOLTMETER
uint16_t VOLTAGE = 0;
uint16_t VOLTAGE_M[3] = {0};
uint8_t VOLTAGE_CYCLE = 0;
uint32_t VOLTAGE_AV = 0;
uint16_t voltm = 0;

///////////////////////////////////////RESIST
uint32_t RESISTANCE = 0;
uint32_t RESIST_M[3] = {0};
uint8_t RESIST_CYCLE = 0;
uint32_t RESIST_AV = 0;
uint32_t resistm = 0;

///////////////////////////////////////PROBE
uint16_t VPROBE = 0xFFFF;
uint16_t VPROBE_M[3] = {0};
uint8_t VPROBE_CYCLE = 0;
uint32_t VPROBE_AV = 0;
uint16_t vprobem = 0;
uint32_t VPROBE_UR = 0;

#define R8K 0
#define R20K 1
#define R100K 2
#define Z 2
uint8_t MODE = 0xFF;
uint8_t tmp_MODE = 0xFF;
#define MODE_PM3	0			//8,45 - Z; 20 - Z; 100 - 1; 
#define MODE_P3		1			//8,45 - Z; 20 - Z; 100 - Z;
#define MODE_P6		2			//8,45 - Z; 20 - Z; 100 - 0;
#define MODE_P19	3			//8,45 - Z; 20 - 0; 100 - Z;
#define MODE_P40	4			//8,45 - 0; 20 - Z; 100 - Z;
#define MODE_M16	5			//8,45 - Z; 20 - 1; 100 - z; 
#define MODE_M40	6			//8,45 - 1; 20 - z; 100 - z; 
#define MODE_R100	7			//100
#define MODE_R20	8			//20
#define MODE_R8		9			//8.45
#define MODE_R5		10		//5.607166
#define OSC_PM3		11			//8,45 - Z; 20 - Z; 100 - 1; 
#define OSC_P6		12			//8,45 - Z; 20 - Z; 100 - 0;
#define MODE_STN	13
#define MODE_PRB	14			//8,45 - 1; 20 - 1; 100 - 1; 
#define MODE_CP		15			//8,45 - 0; 20 - 0; 100 - 0;
#define MODE_CHRG	16			//8,45 - Z; 20 - 0; 100 - Z;

uint8_t VZ_MODE = 1;
uint8_t POLAR = 1;	// 1 +; 0 -
uint8_t METER_MODE = 0;
#define VOLT			0	 
#define OHM				1			
#define PROBE			2
#define CAP				3
#define OSC				4
#define STNGS			5
uint8_t BUTTON_PRESSED = 0;
uint32_t TURN_OFF_TIM = 0;


///////////////////////////////////////CAPASITY
uint32_t capADC = 0;
uint32_t CAPACITY = 0;
uint32_t ADCCAP[4] = {0};
uint16_t NULLCAP = 4035;
uint8_t cap_range = 0;
uint8_t k;

uint32_t CAP_TABLE[4][8][2] = {
	0,	0,
	4,	5,
	170,	110,
	501,	240,
	2033,	1000,
	3719,	9560,
	3960, 43000,
	4005,	103000,
	
	0,		0,
	0,		0,
	0,		0,
	0,		0,
	131,	103000,
	138,	204000,
	1416,	327000,
	1990,	490000,
	
	0,		0,
	0,		0,
	0,		0,
	0,		0,
	0,		0,
	527,	490000,
	861,	660000,
	1432,	1000000,
	
	0,		0,
	0,		0,
	0,		0,	
	127,	1000000,
	1825,	4330000,
	3709,	47000000,
	3832,	100000000,
	3852,	220000000	};

///////////////////////////////////////OSCILLOSCOPE
uint16_t OSC_FRAME[200];
uint8_t pLine = 0;
uint32_t vmax, vmin, ampl_divider;	
uint32_t rvmax = 2047;
uint32_t rvmin = 2047;
uint8_t sync_offset = 0;
uint32_t sync_lvl = 2047;
uint8_t osc_catch_sync = 0;
uint8_t offset_adc_data = 0;
uint32_t VIND = 0;
uint8_t offset_beam = 0;
uint32_t offset_beam_ampl = 0;	
	
	
uint8_t lvl_l = 0;	
uint8_t trns_cnt = 0;		
uint8_t need_change_osc_sc = 127;	
uint8_t nosync_osc = 0;	
	
uint8_t nOSC_PM3 = 0;
uint8_t nOSC_P6 = 0;	



///////////////////////////////////////SETTINGS
uint8_t needle_pressed = 0;
uint8_t enter_settings = 0;
uint8_t TOTAL_ELEMENTS = 8;
char settings_list[8][12]={"Charge mode ",
													 "Brightness  ",
												   "Auto off    ",
												   "Osc. Scan   ",
													 "Osc. Sync   ",
													 "Batt. Level ",
													 "FW Ver.     ",
													 "Exit        "};
uint8_t STNGSBASE[4] = {0};													 
uint8_t sett_current_element_pos = 1;				//1....5
uint8_t sett_CurrentCursorPosition = 0;			//0...3 position
uint8_t edit_parameter = 0;								//flag in settings menu - entering to edit parameter
uint8_t ScrollLong = 30;								//3...30
uint8_t ScrollPosition = 0;							//0...30-ScrollLong	

///////////////////////////////////////FLASH
	uint8_t need_rewrite_flash = 0;									 
	uint8_t cnd = 0;	
	#define SETUP_START_ADDR   0x08060000		
	#define SECTOR 						 FLASH_SECTOR_7

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



