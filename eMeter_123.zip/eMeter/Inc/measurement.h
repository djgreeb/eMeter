/////////////////////////////////////////////////////////////////////////////////////////////////
// 	measurement process
//	product: eMeter
//
//
//
//
//	Author: Anatska Andrei
//
/////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdint.h"


/////////////////////////////////////////////////////////
//	
//	measurement process
//	
void measurement_process(void)
	{	
	if(METER_MODE==VOLT)	////////////////////////////////////   VOLTMETER	
		{
		tmp_MODE = MODE;				//save current mode		
		SWITCH_MODE(MODE_PM3);	
		HAL_Delay(10);
		HAL_ADC_Start(&hadc1);	
		HAL_Delay(7);	
		ADC_TEMP = HAL_ADC_GetValue(&hadc1);	
		ADC_TEMP = ADC_TEMP*3300;	
		ADC_TEMP = ADC_TEMP>>12;			
		if(ADC_TEMP>3000)					//V>3.000V
			{
			SWITCH_MODE(MODE_P6);
			HAL_Delay(10);
			HAL_ADC_Start(&hadc1);	
			HAL_Delay(7);	
			ADC_TEMP = HAL_ADC_GetValue(&hadc1);	
			ADC_TEMP = ADC_TEMP*6600;	
			ADC_TEMP = ADC_TEMP>>12;
			if(ADC_TEMP<200)
				{	
				POLAR = 1;	
				VOLTAGE = 0;
				if(VZ_MODE==0)
					{					
					VZ_MODE = 1;		
					need_update_display = 1;
					}						
				}
			else
				{
				if(VZ_MODE==1)
					{					
					VZ_MODE = 0;		
					need_update_display = 1;
					}			
				}		
			}
		else
			{
			if(VZ_MODE==1)
				{					
				VZ_MODE = 0;		
				need_update_display = 1;
				}					
			}	
		SWITCH_MODE(tmp_MODE);
		if(VZ_MODE==0)				//measurement process
			{
			HAL_Delay(10);	
			HAL_ADC_Start(&hadc1);	
			HAL_Delay(7);	
			ADC_TEMP = HAL_ADC_GetValue(&hadc1);				
			if(MODE==MODE_PM3)
				{
				ADC_TEMP = ADC_TEMP*6600;	
				ADC_TEMP = ADC_TEMP>>12;	
				if(ADC_TEMP>6300)							//V>3.15
					{
					SWITCH_MODE(MODE_P6);	
					}
				else if(ADC_TEMP<30)				//V< -3.3V
					{
					SWITCH_MODE(MODE_M16);	
					}
				else if((3330<ADC_TEMP) && (ADC_TEMP<6301))			//V +0.015...3.15
					{
					SWITCH_MODE(MODE_P3);	
					}
				else
					{
					if(ADC_TEMP>3315)
						{
						POLAR = 1;
						VOLTAGE = ADC_TEMP-3315;	
						}	
					else
						{
						POLAR = 0;
						VOLTAGE = 3315-ADC_TEMP;	
						}					
					}
				}	
			else if(MODE==MODE_P3)
				{
				ADC_TEMP = ADC_TEMP*3300;	
				ADC_TEMP = ADC_TEMP>>12;		
				if(ADC_TEMP>3100)
					{
					SWITCH_MODE(MODE_P6);	
					}
				else if(ADC_TEMP<30)
					{
					SWITCH_MODE(MODE_PM3);	
					}
				else
					{
					POLAR = 1;
					VOLTAGE = ADC_TEMP;		
					}			
				}	
			else if(MODE==MODE_P6)
				{
				ADC_TEMP = ADC_TEMP*6617;	
				ADC_TEMP = ADC_TEMP>>12;		
				if(ADC_TEMP>6300)
					{
					SWITCH_MODE(MODE_P19);	
					}
				else if(ADC_TEMP<2700)
					{
					SWITCH_MODE(MODE_PM3);	
					}
				else
					{
					POLAR = 1;
					VOLTAGE = ADC_TEMP;		
					}	
				}	
			else if(MODE==MODE_P19)
				{
				ADC_TEMP = ADC_TEMP*19768;	
				ADC_TEMP = ADC_TEMP>>12;
				if(ADC_TEMP>18520)
					{
					SWITCH_MODE(MODE_P40);	
					}
				else if(ADC_TEMP<5000)
					{
					SWITCH_MODE(MODE_P6);	
					}
				else
					{
					POLAR = 1;
					VOLTAGE = ADC_TEMP;		
					}					
				}
			else if(MODE==MODE_P40)
				{
				ADC_TEMP = ADC_TEMP*42296;	
				ADC_TEMP = ADC_TEMP>>12;
				if(ADC_TEMP>40000)
					{
					POLAR = 1;
					VOLTAGE = 0xFFFF;					//overflow
					}
				else if(ADC_TEMP<17000)
					{
					SWITCH_MODE(MODE_P19);	
					}
				else
					{
					POLAR = 1;
					VOLTAGE = ADC_TEMP;		
					}					
				}	
			else if(MODE==MODE_M16)
				{
				if(ADC_TEMP>3413)
					{
					ADC_TEMP = 3413;	
					}				
				ADC_TEMP = 3413-ADC_TEMP;	
				ADC_TEMP = ADC_TEMP*16423;	
				ADC_TEMP = ADC_TEMP/3413;
				if(ADC_TEMP>15500)
					{
					SWITCH_MODE(MODE_M40);	
					}
				else if(ADC_TEMP<2660)
					{
					SWITCH_MODE(MODE_PM3);	
					}
				else
					{
					POLAR = 0;
					VOLTAGE = ADC_TEMP;		
					}			
				}		
			else if(MODE==MODE_M40)
				{
				if(ADC_TEMP>3776)
					{
					ADC_TEMP = 3776;	
					}				
				ADC_TEMP = 3776-ADC_TEMP;	
				ADC_TEMP = ADC_TEMP*38937;	
				ADC_TEMP = ADC_TEMP/3776;
				if(ADC_TEMP>38700)
					{
					POLAR = 0;
					VOLTAGE = 0xFFFF;					//overflow
					}
				else if(ADC_TEMP<14000 && POLAR==0)
					{
					SWITCH_MODE(MODE_M16);	
					}
				else
					{
					POLAR = 0;
					VOLTAGE = ADC_TEMP;		
					}			
				}		
			need_update_display = 1;
			}		
		}
	else if(METER_MODE==OHM)	////////////////////////////////////resistance
		{	
		HAL_ADC_Start(&hadc1);	
		HAL_Delay(27);	
		ADC_TEMP = HAL_ADC_GetValue(&hadc1);	
	
		if(MODE==MODE_R100)
			{
			if(ADC_TEMP==4095)
				{
				RESISTANCE = 0xFFFFFFFF;						//over	
				}
			else
				{							
				ADC_TEMP = (100000*ADC_TEMP)/(4095-ADC_TEMP);	
				}
		
			if(ADC_TEMP>4000000)								//4M max
				{
				RESISTANCE = 0xFFFFFFFF;						//over		
				}
			else if(ADC_TEMP<42000)
				{
				SWITCH_MODE(MODE_R20);	
				}
			else
				{
				if(ADC_TEMP>1600000)
					{
					RESISTANCE = ADC_TEMP + 450000;	
					}					
				else if(ADC_TEMP>1100000)
					{
					RESISTANCE = ADC_TEMP + 295000;	
					}			
				else if(ADC_TEMP>790000)
					{
					RESISTANCE = ADC_TEMP + 111050;	
					}		
				else if(ADC_TEMP>420000)
					{
					RESISTANCE = ADC_TEMP + 30400;	
					}		
				else if(ADC_TEMP>170000)
					{
					RESISTANCE = ADC_TEMP + 5000;	
					}	
				else if(ADC_TEMP>60000)
					{
					RESISTANCE = ADC_TEMP + 305;	
					}		
				else
					{					
					RESISTANCE = ADC_TEMP;
					}						
				}
			}	
		else if(MODE==MODE_R20)
			{
			if(ADC_TEMP==4095)
				{
				SWITCH_MODE(MODE_R100);	
				}
			else
				{							
				ADC_TEMP = (20335*ADC_TEMP)/(4095-ADC_TEMP);	
				}
				
			if(ADC_TEMP>48000)						
				{
				SWITCH_MODE(MODE_R100);		
				}
			else if(ADC_TEMP<12000)
				{
				SWITCH_MODE(MODE_R8);	
				}
			else
				{
				RESISTANCE = ADC_TEMP;	
				}
			}
		else if(MODE==MODE_R8)
			{
			if(ADC_TEMP==4095)
				{
				SWITCH_MODE(MODE_R20);	
				}
			else
				{							
				ADC_TEMP = (8552*ADC_TEMP)/(4095-ADC_TEMP);	
				}
				
			if(ADC_TEMP>14000)						
				{
				SWITCH_MODE(MODE_R20);		
				}
			else if(ADC_TEMP<6000)
				{
				SWITCH_MODE(MODE_R5);	
				}
			else
				{
				RESISTANCE = ADC_TEMP;	
				}
			}
		else if(MODE==MODE_R5)
			{
			if(ADC_TEMP==4095)
				{
				SWITCH_MODE(MODE_R8);	
				}
			else
				{							
				ADC_TEMP = (5645*ADC_TEMP)/(4095-ADC_TEMP);	
				}
			if(ADC_TEMP>7000)						
				{
				SWITCH_MODE(MODE_R8);		
				}
			else
				{
				if(ADC_TEMP>0)
					{
					if(ADC_TEMP<250)
						{
						RESISTANCE = ADC_TEMP - 1;	
						}						
					else if(ADC_TEMP>4500)
						{
						RESISTANCE = ADC_TEMP + 20;	
						}
					else
						{
						RESISTANCE = ADC_TEMP;	
						}						
					}
				else
					{
					RESISTANCE = ADC_TEMP;	
					}					
				}
			}
		need_update_display = 1;	
		}	
	else if(METER_MODE==PROBE)		////////////////////////////////////    PROBE
		{
		HAL_Delay(20);	
		HAL_ADC_Start(&hadc1);	
		HAL_Delay(7);	
		ADC_TEMP = HAL_ADC_GetValue(&hadc1);		
		ADC_TEMP = 3000*ADC_TEMP;
		ADC_TEMP = ADC_TEMP/4095;	
		if(ADC_TEMP>2500)
			{
			VPROBE = 0xFFFF;	
			}			
		else
			{
			VPROBE = ADC_TEMP;	
			}			
		need_update_display = 1;	
		}
	else if(METER_MODE==CAP)				////////////////////////////////////     CAPACITOR
		{
		if(cap_range==0)
			{
			HAL_Delay(40);
			GPIOA->BSRR = 0x0000001C;					//3 pins to SET		
			HAL_ADC_Start(&hadc1);
			HAL_Delay(7);	
			ADC_TEMP = HAL_ADC_GetValue(&hadc1);	
			GPIOA->BSRR = 0x001C0000;					//3 pins to RESET	
			ADCCAP[cap_range] = (7*ADCCAP[cap_range] + ADC_TEMP);
			ADCCAP[cap_range] = ADCCAP[cap_range]>>3;	
			if(ADCCAP[cap_range]>NULLCAP)
				{
				NULLCAP = ADCCAP[cap_range];	
				capADC = 0;	
				}			
			else
				{
				capADC = NULLCAP - ADCCAP[cap_range];	
				}	
			if(capADC>4005)
				{
				NULLCAP = 4035;
				cap_range = 1;	
				}	
			else
				{
				for(k=1;k<8;k++)
					{
					if(capADC<=CAP_TABLE[cap_range][k][0])
						{
						CAPACITY = (capADC - CAP_TABLE[cap_range][k-1][0])*(CAP_TABLE[cap_range][k][1]-CAP_TABLE[cap_range][k-1][1]);
						CAPACITY = CAPACITY/(CAP_TABLE[cap_range][k][0]-CAP_TABLE[cap_range][k-1][0]);
						CAPACITY+=CAP_TABLE[cap_range][k-1][1]; 	
						k = 100;	
						}						
					}					
				need_update_display = 1;	
				}					
			}				
		else if(cap_range==1)
			{
			HAL_Delay(40);
			GPIOA->BSRR = 0x0000001C;					//3 pins to SET		
			HAL_Delay(1);		
			HAL_ADC_Start(&hadc1);
			HAL_Delay(7);	
			ADC_TEMP = HAL_ADC_GetValue(&hadc1);	
			GPIOA->BSRR = 0x001C0000;					//3 pins to RESET	
			ADCCAP[cap_range] = (7*ADCCAP[cap_range] + ADC_TEMP);
			ADCCAP[cap_range] = ADCCAP[cap_range]>>3;	
			if(ADCCAP[cap_range]>NULLCAP)
				{
				NULLCAP = ADCCAP[cap_range];	
				capADC = 0;	
				}			
			else
				{
				capADC = NULLCAP - ADCCAP[cap_range];	
				}	
			if(capADC<131)
				{
				NULLCAP = 4035;
				cap_range = 0;	
				}	
			else if(capADC>1990)
				{
				NULLCAP = 4035;
				cap_range = 2;	
				}	
			else
				{
					
				for(k=1;k<8;k++)
					{
					if(capADC<=CAP_TABLE[cap_range][k][0])
						{
						CAPACITY = (capADC - CAP_TABLE[cap_range][k-1][0])*(CAP_TABLE[cap_range][k][1]-CAP_TABLE[cap_range][k-1][1]);
						CAPACITY = CAPACITY/(CAP_TABLE[cap_range][k][0]-CAP_TABLE[cap_range][k-1][0]);
						CAPACITY+=CAP_TABLE[cap_range][k-1][1]; 	
						k = 100;	
						}						
					}		
				need_update_display = 1;	
				}			
			}	
		else if(cap_range==2)
			{
			HAL_Delay(200);
			GPIOA->BSRR = 0x0000001C;					//3 pins to SET		
			HAL_Delay(5);		
			HAL_ADC_Start(&hadc1);
			HAL_Delay(7);	
			ADC_TEMP = HAL_ADC_GetValue(&hadc1);	
			GPIOA->BSRR = 0x001C0000;					//3 pins to RESET	
			ADCCAP[cap_range] = (3*ADCCAP[cap_range] + ADC_TEMP);
			ADCCAP[cap_range] = ADCCAP[cap_range]>>2;	
			if(ADCCAP[cap_range]>NULLCAP)
				{
				NULLCAP = ADCCAP[cap_range];	
				capADC = 0;	
				}			
			else
				{
				capADC = NULLCAP - ADCCAP[cap_range];	
				}
			if(capADC<527)
				{
				NULLCAP = 4035;
				cap_range = 1;	
				}	
			else if(capADC>1432)
				{
				NULLCAP = 4035;
				cap_range = 3;	
				}	
			else
				{
				for(k=1;k<8;k++)
					{
					if(capADC<=CAP_TABLE[cap_range][k][0])
						{
						CAPACITY = (capADC - CAP_TABLE[cap_range][k-1][0])*(CAP_TABLE[cap_range][k][1]-CAP_TABLE[cap_range][k-1][1]);
						CAPACITY = CAPACITY/(CAP_TABLE[cap_range][k][0]-CAP_TABLE[cap_range][k-1][0]);
						CAPACITY+=CAP_TABLE[cap_range][k-1][1]; 	
						k = 100;	
						}						
					}	
				need_update_display = 1;	
				}				
			}	
		else if(cap_range==3)
			{
			HAL_Delay(800);
			GPIOA->BSRR = 0x0000001C;					//3 pins to SET		
			HAL_Delay(20);		
			HAL_ADC_Start(&hadc1);
			HAL_Delay(7);	
			ADC_TEMP = HAL_ADC_GetValue(&hadc1);	
			GPIOA->BSRR = 0x001C0000;					//3 pins to RESET	
			ADCCAP[cap_range]+=ADC_TEMP;
			ADCCAP[cap_range] = ADCCAP[cap_range]>>1;	
			if(ADCCAP[cap_range]>NULLCAP)
				{
				NULLCAP = ADCCAP[cap_range];	
				capADC = 0;	
				}			
			else
				{
				capADC = NULLCAP - ADCCAP[cap_range];	
				}			
			if(capADC<127)
				{
				NULLCAP = 4035;
				cap_range = 2;	
				}	
			else
				{
				for(k=1;k<8;k++)
					{
					if(capADC<=CAP_TABLE[cap_range][k][0])
						{
						CAPACITY = (capADC - CAP_TABLE[cap_range][k-1][0])*(CAP_TABLE[cap_range][k][1]-CAP_TABLE[cap_range][k-1][1]);
						CAPACITY = CAPACITY/(CAP_TABLE[cap_range][k][0]-CAP_TABLE[cap_range][k-1][0]);
						CAPACITY+=CAP_TABLE[cap_range][k-1][1]; 	
						k = 100;	
						}						
					}	
				need_update_display = 1;	
				}
			}		
		}	
	else if(METER_MODE==OSC)				//////////////////////////////////////    oscilloscope mode	
		{
		HAL_ADC_Start_DMA(&hadc1, (uint32_t*)OSC_FRAME, 200);			
		HAL_Delay(delay_factor);	
		/////////offset data due to ADC artifact///////////		
		if(CURRENT_FxMS>3)
			{
			if(CURRENT_FxMS==4)
				{
				offset_adc_data = 3;	
				}	
			else if(CURRENT_FxMS==5)
				{
				offset_adc_data = 4;	
				}					
			else if(CURRENT_FxMS==6)
				{
				offset_adc_data = 5;	
				}						
			else if(CURRENT_FxMS==7)
				{
				offset_adc_data = 8;	
				}
			else if(CURRENT_FxMS==8)
				{
				offset_adc_data = 20;	
				}	
			else if(CURRENT_FxMS==9)
				{
				offset_adc_data = 26;	
				}	
			for(pLine=0;pLine<173;pLine++)					
				{	
				OSC_FRAME[pLine] = OSC_FRAME[pLine+offset_adc_data];	
				}		
			}			
			
		vmax = OSC_FRAME[0];	
		vmin = OSC_FRAME[0];	
			
		for(pLine=0;pLine<173;pLine++)					//search min and max
			{
			if(vmax<OSC_FRAME[pLine])
				{
				vmax = OSC_FRAME[pLine];	
				}				
			if(vmin>OSC_FRAME[pLine])
				{
				vmin = OSC_FRAME[pLine];	
				}	
			}			


		if(CURRENT_FxMS>5)
			{
			if(vmax>rvmax)
				{
				rvmax = (9*rvmax+vmax)/10;
				}			
			else
				{			
				rvmax = (29*rvmax+vmax)/30;
				}
			if(vmin<rvmin)
				{
				rvmin = (9*rvmin+vmin)/10;
				}			
			else
				{			
				rvmin = (29*rvmin+vmin)/30;
				}	
			}
		else if(CURRENT_FxMS>1)
			{
			if(vmax>rvmax)
				{
				rvmax = (2*rvmax+vmax)/3;
				}			
			else
				{			
				rvmax = (9*rvmax+vmax)/10;
				}
			if(vmin<rvmin)
				{
				rvmin = (2*rvmin+vmin)/3;
				}			
			else
				{			
				rvmin = (9*rvmin+vmin)/10;
				}		
			}
		else
			{
			if(vmax>rvmax)
				{
				rvmax = (rvmax+vmax)/2;
				}			
			else
				{			
				rvmax = (2*rvmax+vmax)/3;
				}
			if(vmin<rvmin)
				{
				rvmin = (rvmin+vmin)/2;
				}			
			else
				{			
				rvmin = (2*rvmin+vmin)/3;
				}		
			}			
			
		for(pLine=0;pLine<173;pLine++)					//delete min offset
			{
			if(rvmin>OSC_FRAME[pLine])
				{
				OSC_FRAME[pLine] = 0;	
				}				
			else
				{				
				OSC_FRAME[pLine] = OSC_FRAME[pLine]-rvmin;
				}
			}
			
		sync_lvl = (rvmax-rvmin)/2;							//sync process
		pLine = 45;
		sync_offset = 0xFF;	
			
		if(STNGSBASE[3]==0)		//sync type selector	
			{
			while(pLine<128)							//search threshold moment	
				{
				if(OSC_FRAME[pLine]<=sync_lvl)
					{
					sync_offset = pLine;	
					pLine = 200;	
					}
				pLine++;		
				}
			pLine = sync_offset;
			sync_offset = 0xFF;
			while(pLine<128)	
				{
				if(OSC_FRAME[pLine]>sync_lvl)
					{
					sync_offset = pLine;
					pLine = 200;	
					}
				pLine++;		
				}
			}
		else
			{
			while(pLine<128)							//search threshold moment	
				{
				if(OSC_FRAME[pLine]>sync_lvl)
					{
					sync_offset = pLine;	
					pLine = 200;	
					}
				pLine++;		
				}
			pLine = sync_offset;
			sync_offset = 0xFF;
			while(pLine<128)	
				{
				if(OSC_FRAME[pLine]<=sync_lvl)
					{
					sync_offset = pLine;
					pLine = 200;	
					}
				pLine++;		
				}	
			}
			
		if(sync_offset==0xFF)   //is sync not found
			{
			sync_offset = 0;
			osc_catch_sync = 0;
			if(STNGSBASE[2]>9)					//osc. scan - auto
				{
				nosync_osc++;
				if(nosync_osc>14)
					{					
					if(CURRENT_FxMS>6)
						{
						ADC_SPEED(CURRENT_FxMS-1);		
						}					
					else if(CURRENT_FxMS<5)
						{
						ADC_SPEED(CURRENT_FxMS+1);	
						}							
					nosync_osc = 0;		
					}	
				}	
			}
		else
			{
			sync_offset-=45;
			osc_catch_sync = 1;	
			nosync_osc = 0;		
			if(STNGSBASE[2]>9)					//osc. scan - auto
				{
				trns_cnt = 0;		
				for(pLine=0;pLine<173;pLine++)					//calculate cnt transients
					{
					if(OSC_FRAME[pLine]<=sync_lvl && lvl_l==0)
						{
						lvl_l = 1;	
						}
					else if(OSC_FRAME[pLine]>sync_lvl && lvl_l==1)
						{
						lvl_l = 0;	
						trns_cnt++;		
						}
					}
				if(trns_cnt<4)				//freq to low
					{
					if(CURRENT_FxMS>0)
						{
						need_change_osc_sc--;	
						}						
					}
				else if(trns_cnt>16) 		//freq to high		
					{
					if(CURRENT_FxMS<9)
						{
						need_change_osc_sc++;	
						}			
					}
				if(need_change_osc_sc>135)					//freq to high
					{
					if(CURRENT_FxMS<9)
						{
						ADC_SPEED(CURRENT_FxMS+1);			
						}		
					need_change_osc_sc = 127;		
					}					
				else if(need_change_osc_sc<119)			//freq to low
					{
					if(CURRENT_FxMS>0)
						{
						ADC_SPEED(CURRENT_FxMS-1);			
						}	
					need_change_osc_sc = 127;		
					}	
				}		
			}
			
		ampl_divider = rvmax-rvmin;		
		ampl_divider = ampl_divider/48; 
		if(ampl_divider>0)
			{				
			for(pLine=0;pLine<91;pLine++)					//delete min offset
				{
				OSC_FRAME[pLine+sync_offset] = OSC_FRAME[pLine+sync_offset]*10;	
				OSC_FRAME[pLine+sync_offset] = OSC_FRAME[pLine+sync_offset]/ampl_divider;
				}
			offset_beam = 0;	
			}
		else
			{
			ampl_divider = rvmax-rvmin;
			ampl_divider = 512 - ampl_divider;
			ampl_divider = ampl_divider/2;	
			if(ampl_divider>15)
				{
				ampl_divider-=14;	
				}				
			for(pLine=0;pLine<91;pLine++)
				{
				OSC_FRAME[pLine+sync_offset]+=ampl_divider;
				}
			offset_beam = 1;	
			}				
				
		for(pLine=0;pLine<91;pLine++)					//normalize amplitude
			{
			OSC_FRAME[pLine+sync_offset] = OSC_FRAME[pLine+sync_offset]>>4;
			if(OSC_FRAME[pLine+sync_offset]>31)
				{
				OSC_FRAME[pLine+sync_offset] = 31;	
				}				
			}
					
		if(MODE==OSC_P6)
			{
			if(offset_beam==0)	
				{
				VIND = rvmax*660;
				VIND = VIND>>12;
				sprintf((char*)Buf, "+%01lu.%02luV ", VIND/100, VIND%100);							
				}
			else
				{
				offset_beam_ampl = ampl_divider;
				VIND = rvmax + offset_beam_ampl;
				VIND = VIND*660;
				VIND = VIND>>12;
				sprintf((char*)Buf, "+%01lu.%02luV ", VIND/100, VIND%100);		
				}
			}	
		else if(MODE==OSC_PM3)
			{
			if(offset_beam==0)	
				{
				if(rvmax>2047)
					{
					VIND = rvmax - 2047;	
					VIND = VIND*330;
					VIND = VIND>>11;
					sprintf((char*)Buf, "+%01lu.%02luV ", VIND/100, VIND%100);		
					}				
				else
					{
					VIND = 2047 - rvmax;	
					VIND = VIND*330;
					VIND = VIND>>11;
					sprintf((char*)Buf, "-%01lu.%02luV ", VIND/100, VIND%100);		
					}	
				}	
			else
				{
				offset_beam_ampl = ampl_divider;
				VIND = rvmax + offset_beam_ampl;
				if(VIND>2047)
					{
					VIND-=2047;	
					VIND = VIND*330;
					VIND = VIND>>11;
					sprintf((char*)Buf, "+%01lu.%02luV ", VIND/100, VIND%100);		
					}				
				else
					{
					VIND = 2047 - VIND;	
					VIND = VIND*330;
					VIND = VIND>>11;
					sprintf((char*)Buf, "-%01lu.%02luV ", VIND/100, VIND%100);		
					}			
				}				
			}
		SSD1306_GotoXY(0, 0);
		SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);
		if(osc_catch_sync)
			{
			sprintf((char*)Buf, "sync");					
			}
		else
			{
			sprintf((char*)Buf, "      ");	
			}			
		SSD1306_GotoXY(0, 7);
		SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);	
		if(CURRENT_FxMS==0)
			{
			sprintf((char*)Buf, "7mS   ");	
			}
		else if(CURRENT_FxMS==1)
			{
			sprintf((char*)Buf, "3.5mS ");		
			}			
		else if(CURRENT_FxMS==2)
			{
			sprintf((char*)Buf, "1.4mS ");		
			}	
		else if(CURRENT_FxMS==3)
			{
			sprintf((char*)Buf, "700uS ");		
			}		
		else if(CURRENT_FxMS==4)
			{
			sprintf((char*)Buf, "350uS ");		
			}	
		else if(CURRENT_FxMS==5)
			{
			sprintf((char*)Buf, "140uS ");		
			}		
		else if(CURRENT_FxMS==6)
			{
			sprintf((char*)Buf, "70uS  ");		
			}	
		else if(CURRENT_FxMS==7)
			{
			sprintf((char*)Buf, "35uS  ");		
			}
		else if(CURRENT_FxMS==8)
			{
			sprintf((char*)Buf, "14uS  ");		
			}
		else if(CURRENT_FxMS==9)
			{
			sprintf((char*)Buf, "7uS   ");		
			}	
		SSD1306_GotoXY(0, 16);
		SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);	
		
		if(MODE==OSC_P6)
			{
			if(offset_beam==0)	
				{
				VIND = rvmin*660;
				VIND = VIND>>12;
				sprintf((char*)Buf, "+%01lu.%02luV ", VIND/100, VIND%100);							
				}
			else
				{
				offset_beam_ampl = ampl_divider;
				if(rvmin>=offset_beam_ampl)
					{
					VIND = rvmin - offset_beam_ampl;
					VIND = VIND*660;
					VIND = VIND>>12;
					sprintf((char*)Buf, "+%01lu.%02luV ", VIND/100, VIND%100);		
					}	
				else
					{
					VIND = offset_beam_ampl - rvmin;
					VIND = VIND*660;
					VIND = VIND>>12;
					sprintf((char*)Buf, "-%01lu.%02luV ", VIND/100, VIND%100);		
					}
				}
			}	
		else if(MODE==OSC_PM3)
			{
			if(offset_beam==0)	
				{	
				if(rvmin>2047)
					{
					VIND = rvmin - 2047;
					VIND = VIND*330;
					VIND = VIND>>11;
					sprintf((char*)Buf, "+%01lu.%02luV ", VIND/100, VIND%100);		
					}				
				else
					{
					VIND = 2047 - rvmin;	
					VIND = VIND*330;
					VIND = VIND>>11;
					sprintf((char*)Buf, "-%01lu.%02luV ", VIND/100, VIND%100);		
					}	
				}
			else
				{
				offset_beam_ampl = ampl_divider;
				VIND = rvmin + 10000;
				VIND-=offset_beam_ampl; 	
				if(VIND>12047)
					{
					VIND-= 12047;	
					VIND = VIND*330;
					VIND = VIND>>11;
					sprintf((char*)Buf, "+%01lu.%02luV ", VIND/100, VIND%100);		
					}				
				else
					{
					VIND = 12047 - VIND;	
					VIND = VIND*330;
					VIND = VIND>>11;
					sprintf((char*)Buf, "-%01lu.%02luV ", VIND/100, VIND%100);		
					}	
				}	
			}	
		SSD1306_GotoXY(0, 25);
		SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);	
			
		if(MODE==OSC_PM3)
			{
			if((rvmax>4000) && (rvmin>1800))
				{
				nOSC_P6++;	
				}	
			}			
		else if(MODE==OSC_P6)
			{
			if((rvmax<2400) && (rvmin<10))
				{
				nOSC_PM3++;	
				}	
			}	
			
		if(nOSC_P6>8)							//change voltage range
			{
			SWITCH_MODE(OSC_P6);	
			nOSC_PM3 = 0;
			nOSC_P6 = 0;	
			rvmax = 2047;
			rvmin = 2047;		
			}				
		else if(nOSC_PM3>8)			//change voltage range
			{
			SWITCH_MODE(OSC_PM3);	
			nOSC_PM3 = 0;
			nOSC_P6 = 0;	
			rvmax = 2047;
			rvmin = 2047;		
			}		
			
			
			
		Draw_osc_background();	
		for(pLine=0;pLine<90;pLine++)
			{
			SSD1306_DrawLine(37+pLine, 31-OSC_FRAME[pLine+sync_offset], 38+pLine, 31-OSC_FRAME[pLine+1+sync_offset], SSD1306_COLOR_WHITE);		
			}		
		need_update_display = 1;	
		}	
	else if(METER_MODE==STNGS)				//////////////////////////////////////    settings
		{	
		HAL_Delay(10);	
		HAL_ADC_Start(&hadc1);	
		HAL_Delay(17);	
		ADC_TEMP = HAL_ADC_GetValue(&hadc1);	
		if(CHARGE_MODE==0)							//adc for setting key	
			{
			if((ADC_TEMP<3200) && needle_pressed==0)
				{
				if(enter_settings==0)					//enter to settings menu;
					{
					SSD1306_Fill(SSD1306_COLOR_BLACK);		
					sett_current_element_pos = 1;	
					sett_CurrentCursorPosition = 0;
					ReDrawScroll(TOTAL_ELEMENTS, sett_current_element_pos);	
					int_SETT_DRAW_ALL_SETTINGS();
					need_update_display = 1;
					enter_settings = 1;	
					}
				else
					{
					if(edit_parameter==0)
						{
						if((sett_current_element_pos+sett_CurrentCursorPosition)>1 && (sett_current_element_pos+sett_CurrentCursorPosition)<6)	
							{
							edit_parameter = 1;	
							SSD1306_Fill(SSD1306_COLOR_BLACK);	
							ReDrawScroll(TOTAL_ELEMENTS, sett_current_element_pos);	
							int_SETT_DRAW_ALL_SETTINGS();		
							}
						else if(sett_current_element_pos+sett_CurrentCursorPosition==1)		//Enter charge mode
							{
							CHARGE_MODE = 1;	
							SSD1306_Fill(SSD1306_COLOR_BLACK);
							SSD1306_UpdateScreen();
							ssd1306_I2C_Write(0x78, 0x00, (0x81));		//Set Contrast Control
							ssd1306_I2C_Write(0x78, 0x00, 0x00);			// minimal contrast
							sprintf((char*)Buf, "CHARGE MODE");	
							SSD1306_GotoXY(29, 15);
							SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);	
							SSD1306_UpdateScreen();	
							HAL_Delay(1800);							
							ADC_SPEED(DEF_TIME_FREQ);	
							SWITCH_MODE(MODE_CHRG);		
							HAL_GPIO_WritePin(GPIOA, OHM_EN_Pin, GPIO_PIN_RESET);	
							HAL_GPIO_WritePin(GPIOA, CHRG_EN_Pin, GPIO_PIN_RESET);		
							SSD1306_Fill(SSD1306_COLOR_BLACK);
							Draw_Battery();																												//
							previous_battery_level = 0;																						// force redraw	
							Draw_Level_Battery(BAT_PIX_LVL);																			//
							sprintf((char*)Buf, "RANGE 11.7-13.0V");	
							SSD1306_GotoXY(0, 0);
							SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);	
							need_update_display = 1;	
							enter_settings = 0;	
							}	
						else if(sett_current_element_pos+sett_CurrentCursorPosition==8)		//Exit
							{	
							for(cnd=0;cnd<4;cnd++)				//if data is changed - save to FLASH memory!		
								{
								if(STNGSBASE[cnd]!=((volatile uint8_t*)(SETUP_START_ADDR+(16*cnd)))[0])
									{
									need_rewrite_flash = 1;	
									}			
								}				
							if(need_rewrite_flash)
								{
								SSD1306_DrawFilledRectangle(0, 0, 128, 32, SSD1306_COLOR_BLACK);
								sprintf((char*)Buf, "Save settings");	
								SSD1306_GotoXY(20, 15);
								SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);		
								SSD1306_UpdateScreen();		
								HAL_Delay(1800);	
								}
							edit_parameter = 0;	
							ADC_SPEED(DEF_TIME_FREQ);
							SWITCH_MODE(MODE_STN);		
							HAL_GPIO_WritePin(GPIOA, OHM_EN_Pin, GPIO_PIN_RESET);	
							HAL_GPIO_WritePin(GPIOA, CHRG_EN_Pin, GPIO_PIN_RESET);	
							SSD1306_DrawFilledRectangle(0, 0, 128, 32, SSD1306_COLOR_BLACK);			//	
							Draw_Battery();																												//
							previous_battery_level = 0;																						// force redraw	
							Draw_Level_Battery(BAT_PIX_LVL);																			//
							sprintf((char*)Buf, "SETTINGS");	
							SSD1306_GotoXY(0, 0);
							SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);		
							SSD1306_UpdateScreen();
							Draw_Animation_MENU(METER_MODE);	
							HAL_Delay(800);					
							SSD1306_DrawFilledRectangle(0, 8, 128, 24, SSD1306_COLOR_BLACK);
							sprintf((char*)Buf, "Short the needle");	
							SSD1306_GotoXY(22, 15);
							SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);
							sprintf((char*)Buf, "to enter the settings");	
							SSD1306_GotoXY(7, 25);
							SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);
							enter_settings = 0;
							}	
						}
					else
						{
						edit_parameter = 0;	
						SSD1306_Fill(SSD1306_COLOR_BLACK);	
						ReDrawScroll(TOTAL_ELEMENTS, sett_current_element_pos);	
						int_SETT_DRAW_ALL_SETTINGS();	
						need_update_display = 1;		
						}
					}				
				needle_pressed = 1;	
				}
			else if((ADC_TEMP>3400) && needle_pressed==1)
				{
				HAL_Delay(200);	
				needle_pressed = 0;	
				}			
			}
		else					//adc for CHARGE MODE
			{
			ADC_TEMP = ADC_TEMP*7920;	
			ADC_TEMP = ADC_TEMP>>14;
			INPUT_V_LVL = 7*INPUT_V_LVL;
			INPUT_V_LVL+= ADC_TEMP;
			INPUT_V_LVL = INPUT_V_LVL>>3;	
			if(INPUT_V_LVL<30)
				{
				INPUT_V_LVL = 0;	
				}				
			if(previous_INPUT_V_LVL!=INPUT_V_LVL)	
				{
				if(CURRENT_ON==0)
					{
					if((INPUT_V_LVL>1170) && (INPUT_V_LVL<1300))
						{
						CURRENT_ON = 1;
						HAL_GPIO_WritePin(GPIOA, CHRG_EN_Pin, GPIO_PIN_SET);			//charge on	
						for(cnt=0;cnt<288;cnt++)
							{
							if(((image_charge[cnt/8]<<(cnt%8))&0x80)!=0)
								{
								SSD1306_DrawPixel(85+(cnt%16), 11+(cnt/16), SSD1306_COLOR_WHITE);	
								}
							}													
						}					
					}				
				else
					{
					if((INPUT_V_LVL<1120) || (INPUT_V_LVL>1320))
						{
						CURRENT_ON = 0;
						HAL_GPIO_WritePin(GPIOA, CHRG_EN_Pin, GPIO_PIN_RESET);			//charge off	
						SSD1306_DrawFilledRectangle(85, 11, 16, 18, SSD1306_COLOR_BLACK);							
						}		
					}				
				SSD1306_GotoXY(0, 12);			
				sprintf((char*)Buf, "INPUT %01lu.%01luV  ", INPUT_V_LVL/100, (INPUT_V_LVL%100)/10);	
				SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);		
				previous_INPUT_V_LVL = INPUT_V_LVL;	
				need_update_display = 1;	
				}
			if(CURRENT_ON==0)
				{
				BAT_INDICATE = BAT_V_LVL;	
				}
			else
				{
				if(BAT_V_LVL>BAT_INDICATE)	
					{
					BAT_INDICATE = BAT_V_LVL;	
					}
				else
					{
					if((BAT_INDICATE-BAT_V_LVL)>90)
						{
						BAT_INDICATE = BAT_V_LVL;		
						}						
					}
				}
			if(previous_BAT_INDICATE!=BAT_INDICATE)
				{				
				SSD1306_GotoXY(0, 24);			
				sprintf((char*)Buf, "BATT. %01lu.%02luV", BAT_INDICATE/100, BAT_INDICATE%100);	
				SSD1306_Puts(Buf, &Font_4x6, SSD1306_COLOR_WHITE);
				previous_BAT_INDICATE = BAT_INDICATE;	
				need_update_display = 1;	
				}
			if((CURRENT_ON==1) && (BAT_V_LVL>421))		//charge end and power off
				{	
				POWER_OFF();	
				}
			}
		}
	}; 	


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



